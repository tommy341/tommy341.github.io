THESE MACROS CAN BE FOUND IN:
https://github.com/raphaelcsc911/Macros

IF YOU ALREADY HAVE SOME INSTALLED:
%appdata%\Gold Menu\macros