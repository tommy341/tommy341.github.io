Keybinds:
	(Disabled while doing any actions that disable keyboard)
	Alt + Backspace (End Program)
	Alt + M (Open Settings)


Notes:
	Putting Primary or Main in the name of your .txt save file will make it auto-import on opening the executor. Use only one as I have not tested multiple primary save files.
	Alt + Backspace is a good key to remember if the program does bug out.
	You can pin the .exe to the taskbar.
	

Fast Toggle:
	Only first page's macros are fast toggleable.
	Alt + Number fast toggles the respective macro:
		1: Inverse Controls
		2: Movement
		3: Pender
		4: Autoshout
		5: Trash Talk
		6: Vow of Mastery/Callouts (Default is Callouts)
		7: Fast Log
		8: Bombs
		9: Auto Green Reinforce (Reinforce key should be on 0)


Persistent Numpad Keys:
	These always work when in Roblox.
	Numpad Zero: /
	Numpad Dot: Fast /c System
	Numpad Enter: Fast /!mb all
	Numpad Plus: Fast guild base callout


Pender:
	X can toggle the autoclicker as well as disable the Pender macro alongside the autoclicker.
	P will only toggle the autoclicker.


Perfect Cast:
	Do not perfect cast:
	(Messes up the mantra)
		Dash
	(Tools)
		Discovery of Fire
		Ardour Scream
		Etc.
	(Instant mantras)
		Spark Swap
  
	Do note that short cancel window mantras may still be perfect casted, such as:
		Taunt
		Lightning Stream


Rollcast Movement Support:
	Manual:
		Nothing
	Partial:
		Moves forward if W/A/S/D is not held.
	Full:
		Always moves forward (not recommended).


Change Trash Talk Lines:
	The file is in the Important\Text Files directory.
	Use a new line (Enter) to split the possible trash talk lines.